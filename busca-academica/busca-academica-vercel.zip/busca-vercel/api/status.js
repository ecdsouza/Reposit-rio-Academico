module.exports = function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.status(200).json({ status: 'ok', versao: '1.0.0', fontes: ['CAPES', 'SciELO', 'BDTD'] });
};
