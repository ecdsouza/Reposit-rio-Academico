/**
 * ============================================================
 *  BUSCA ACADÊMICA — Serverless Function para Vercel
 *  GET /api/search?q=termo&fontes=capes,scielo,bdtd
 * ============================================================
 */

const axios  = require('axios');
const xml2js = require('xml2js');

// ─── CORS helper ────────────────────────────────────────────
function setCORS(res) {
  res.setHeader('Access-Control-Allow-Origin',  '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

// ─── Normalizar registro ─────────────────────────────────────
function norm(obj) {
  return {
    repositorio          : obj.repositorio          || '',
    link_capes           : obj.link_capes           || '',
    link_scielo          : obj.link_scielo          || '',
    revista              : obj.revista              || '',
    classificacao        : obj.classificacao        || '',
    ano_da_publicacao    : obj.ano_da_publicacao    || '',
    volume               : obj.volume               || '',
    titulo_do_periodico  : obj.titulo_do_periodico  || '',
    resumo               : obj.resumo               || '',
    palavras_chaves      : obj.palavras_chaves      || '',
    autor                : obj.autor                || '',
    titulacao            : obj.titulacao            || '',
    instituicao_programa : obj.instituicao_programa || '',
    regiao               : obj.regiao               || '',
    validacao            : obj.validacao            || 'Pendente',
    status_mesclagem     : obj.status_mesclagem     || 'Novo',
  };
}

// ─────────────────────────────────────────────────────────────
//  1. CAPES — Dados Abertos + API interna
// ─────────────────────────────────────────────────────────────
async function searchCAPES(query) {
  const results = [];

  // Tentativa 1: API interna do catálogo de teses
  try {
    const { data } = await axios.get(
      `https://catalogodeteses.capes.gov.br/catalogo-teses/rest/busca?q=${encodeURIComponent(query)}&filtros=&pagina=1&tamanho=20`,
      {
        timeout: 12000,
        headers: {
          'Accept'        : 'application/json, text/plain, */*',
          'Referer'       : 'https://catalogodeteses.capes.gov.br/',
          'User-Agent'    : 'Mozilla/5.0 (compatible; BuscaAcademica/1.0)',
          'Origin'        : 'https://catalogodeteses.capes.gov.br',
        },
      }
    );

    const items = data.teses || data.items || data.results || [];
    for (const item of items) {
      results.push(norm({
        repositorio          : 'CAPES',
        link_capes           : item.idTese
          ? `https://catalogodeteses.capes.gov.br/catalogo-teses/#!/detalhes/${item.idTese}`
          : '',
        titulo_do_periodico  : item.titulo || item.title || '',
        autor                : item.autor  || (item.autores || [])[0] || '',
        ano_da_publicacao    : String(item.anoDaDefesa || item.ano || ''),
        titulacao            : item.grau   || item.nivel || '',
        instituicao_programa : item.siglaIes || item.instituicao || '',
        regiao               : item.regiao || '',
        resumo               : item.resumo || item.abstract || '',
        palavras_chaves      : Array.isArray(item.palavrasChave)
          ? item.palavrasChave.join('; ')
          : (item.palavrasChave || ''),
        classificacao        : item.grau || 'Tese/Dissertação',
      }));
    }
    if (results.length) return results;
  } catch (_) {}

  // Tentativa 2: Dados Abertos CAPES
  try {
    const { data } = await axios.get(
      `https://dadosabertos.capes.gov.br/api/3/action/datastore_search?resource_id=b7003093-4fab-4b88-b0fa-b7d8df0bcb77&q=${encodeURIComponent(query)}&limit=20`,
      { timeout: 10000 }
    );
    for (const r of (data?.result?.records || [])) {
      results.push(norm({
        repositorio          : 'CAPES',
        titulo_do_periodico  : r.NM_TITULO || '',
        autor                : r.NM_AUTOR  || '',
        ano_da_publicacao    : String(r.AN_BASE || ''),
        titulacao            : r.NM_GRAU_ACADEMICO || '',
        instituicao_programa : r.SG_IES   || r.NM_IES || '',
        regiao               : r.NM_REGIAO || '',
        resumo               : r.DS_RESUMO || '',
        palavras_chaves      : r.DS_PALAVRA_CHAVE || '',
        classificacao        : r.NM_GRAU_ACADEMICO || 'Tese/Dissertação',
      }));
    }
  } catch (_) {}

  return results;
}

// ─────────────────────────────────────────────────────────────
//  2. SciELO — Search API
// ─────────────────────────────────────────────────────────────
async function searchSciELO(query) {
  const results = [];

  try {
    const { data } = await axios.get(
      `https://search.scielo.org/?q=${encodeURIComponent(query)}&lang=pt&count=20&from=0&output=json&format=json`,
      { timeout: 12000, headers: { 'Accept': 'application/json' } }
    );
    for (const h of (data?.hits?.hits || [])) {
      const s = h._source || {};
      results.push(norm({
        repositorio         : 'SciELO',
        link_scielo         : s.doi ? `https://doi.org/${s.doi}` : (s.url || ''),
        titulo_do_periodico : s.ti_pt || s.ti_en || '',
        revista             : s.ta || '',
        autor               : Array.isArray(s.au) ? s.au.join('; ') : (s.au || ''),
        ano_da_publicacao   : String(s.da || s.year || ''),
        volume              : s.vi || '',
        resumo              : s.ab_pt || s.ab_en || '',
        palavras_chaves     : Array.isArray(s.wok_subject_categories)
          ? s.wok_subject_categories.join('; ')
          : '',
        classificacao       : 'Artigo Científico',
      }));
    }
  } catch (_) {}

  // Fallback: ArticleMeta API
  if (!results.length) {
    try {
      const { data } = await axios.get(
        `http://articlemeta.scielo.org/api/v1/article/?q=${encodeURIComponent(query)}&collection=scl&count=20&offset=0&format=json`,
        { timeout: 12000 }
      );
      for (const item of (data.objects || [])) {
        const titles    = item.titles    || {};
        const abstracts = item.abstracts || {};
        const authors   = (item.authors || []).map(a => `${a.given_names||''} ${a.surname||''}`.trim()).join('; ');
        const kw        = Object.values(item.keywords || {}).flat().join('; ');
        results.push(norm({
          repositorio         : 'SciELO',
          link_scielo         : item.doi ? `https://doi.org/${item.doi}` : '',
          titulo_do_periodico : titles['pt'] || titles['en'] || Object.values(titles)[0] || '',
          revista             : item.journal_title || '',
          autor               : authors,
          ano_da_publicacao   : String(item.publication_date || ''),
          volume              : item.volume || '',
          resumo              : abstracts['pt'] || abstracts['en'] || '',
          palavras_chaves     : kw,
          classificacao       : 'Artigo Científico',
        }));
      }
    } catch (_) {}
  }

  return results;
}

// ─────────────────────────────────────────────────────────────
//  3. BDTD — API REST + OAI-PMH
// ─────────────────────────────────────────────────────────────
async function searchBDTD(query) {
  const results = [];

  // Tentativa 1: API REST VuFind
  try {
    const { data } = await axios.get(
      `https://bdtd.ibict.br/vufind/api/v1/search?lookfor=${encodeURIComponent(query)}&type=AllFields&sort=relevance&page=1&limit=20`,
      { timeout: 12000 }
    );
    for (const r of (data?.records || [])) {
      results.push(norm({
        repositorio         : 'BDTD',
        titulo_do_periodico : r.title || '',
        autor               : Array.isArray(r.authors) ? r.authors.join('; ') : (r.authors || ''),
        ano_da_publicacao   : String(r.publicationDates?.[0] || ''),
        resumo              : r.summary?.[0] || '',
        palavras_chaves     : Array.isArray(r.subjects) ? r.subjects.flat().join('; ') : '',
        titulacao           : r.formats?.[0] || '',
        instituicao_programa: r.institutions?.[0] || '',
        link_capes          : r.urls?.[0]?.url || '',
        classificacao       : r.formats?.[0] || 'Tese/Dissertação',
      }));
    }
    if (results.length) return results;
  } catch (_) {}

  // Tentativa 2: OAI-PMH
  try {
    const { data } = await axios.get(
      `https://bdtd.ibict.br/vufind/OAI/Server?verb=Search&query=${encodeURIComponent(query)}&queryType=AllFields&method=POST`,
      { timeout: 12000 }
    );
    const parser = new xml2js.Parser({ explicitArray: false });
    const parsed = await parser.parseStringPromise(data);
    const records = parsed?.['OAI-PMH']?.ListRecords?.record || [];
    const list = Array.isArray(records) ? records : [records];
    const get = (meta, k) => {
      const v = meta[k];
      if (!v) return '';
      if (Array.isArray(v)) return v.join('; ');
      if (typeof v === 'object') return v._ || '';
      return v;
    };
    for (const rec of list) {
      const meta = rec?.metadata?.['oai_dc:dc'] || {};
      results.push(norm({
        repositorio         : 'BDTD',
        titulo_do_periodico : get(meta, 'dc:title'),
        autor               : get(meta, 'dc:creator'),
        ano_da_publicacao   : get(meta, 'dc:date'),
        resumo              : get(meta, 'dc:description'),
        palavras_chaves     : get(meta, 'dc:subject'),
        titulacao           : get(meta, 'dc:type'),
        instituicao_programa: get(meta, 'dc:publisher'),
        link_capes          : get(meta, 'dc:identifier'),
        classificacao       : get(meta, 'dc:type'),
      }));
    }
  } catch (_) {}

  return results;
}

// ─────────────────────────────────────────────────────────────
//  HANDLER PRINCIPAL
// ─────────────────────────────────────────────────────────────
module.exports = async function handler(req, res) {
  setCORS(res);

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'GET') {
    res.status(405).json({ erro: 'Método não permitido.' });
    return;
  }

  const { q = '', fontes = 'capes,scielo,bdtd' } = req.query;

  if (!q || q.trim().length < 2) {
    res.status(400).json({ erro: 'Informe um termo de busca com ao menos 2 caracteres.' });
    return;
  }

  const lista = fontes.split(',').map(f => f.trim().toLowerCase());
  const promessas = [];

  if (lista.includes('capes'))  promessas.push(searchCAPES(q));
  if (lista.includes('scielo')) promessas.push(searchSciELO(q));
  if (lista.includes('bdtd'))   promessas.push(searchBDTD(q));

  const resolvidos = await Promise.allSettled(promessas);
  const resultados = resolvidos
    .filter(r => r.status === 'fulfilled')
    .flatMap(r => r.value);

  res.status(200).json({ query: q, total: resultados.length, resultados });
};
