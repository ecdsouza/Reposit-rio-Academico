# 🚀 Como publicar no Vercel — Passo a Passo

## Estrutura do projeto (já pronta)

```
busca-academica-vercel/
├── api/
│   ├── search.js      ← Função serverless (CAPES + SciELO + BDTD)
│   └── status.js      ← Verificação de saúde
├── public/
│   └── index.html     ← Interface web
├── package.json       ← Dependências
└── vercel.json        ← Configuração de rotas
```

---

## Opção A — Publicar pelo site do Vercel (mais fácil)

### 1. Crie uma conta gratuita
Acesse: https://vercel.com e crie uma conta (pode usar o Google ou GitHub)

### 2. Suba o código para o GitHub
1. Acesse https://github.com e crie uma conta (se não tiver)
2. Clique em **"New repository"**
3. Nomeie: `busca-academica`
4. Clique em **"Create repository"**
5. Faça upload dos arquivos desta pasta arrastando para a página do GitHub

### 3. Conecte ao Vercel
1. Acesse https://vercel.com/new
2. Clique em **"Import Git Repository"**
3. Selecione o repositório `busca-academica`
4. Clique em **"Deploy"**
5. Aguarde ~1 minuto

✅ **Pronto!** O Vercel fornece um link como `busca-academica.vercel.app`

---

## Opção B — Publicar pela linha de comando

### 1. Instale o Node.js
https://nodejs.org

### 2. Instale a CLI do Vercel
```bash
npm install -g vercel
```

### 3. Entre na pasta do projeto
```bash
cd busca-academica-vercel
```

### 4. Publique
```bash
vercel
```

Siga as instruções na tela. Na primeira vez, pedirá login.

Para publicar em produção:
```bash
vercel --prod
```

---

## ✅ Testando após o deploy

Acesse a URL fornecida pelo Vercel e teste:
- `https://seu-projeto.vercel.app` → Interface de busca
- `https://seu-projeto.vercel.app/api/status` → Deve retornar `{"status":"ok"}`

---

## ⚠️ Observações

- O Vercel tem limite de **10 segundos** por função serverless (plano gratuito)
- Se uma das fontes demorar, as outras ainda aparecem (busca paralela)
- O Puppeteer **não funciona** no Vercel gratuito — por isso usamos apenas APIs HTTP (Axios + Cheerio)
